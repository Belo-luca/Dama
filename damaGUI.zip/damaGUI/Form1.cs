﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace damaGUI
{
    public partial class Form1 : Form
    {
        string pedinaBianca = "pedinaBianca.jpg";               //Memorizza il nome del file immagine per la pedina bianca.
        string pedinaBiancaCorona = "pedinaBiancaCorona.jpg";   //Memorizza il nome del file immagine per la pedina bianca con la corona.
        string pedinaNera = "pedinaNera.jpg";                   //Memorizza il nome del file immagine per la pedina nera.
        string pedinaNeraCorona = "pedinaNeraCorona.jpg";       //Memorizza il nome del file immagine per la pedina nera con la corona.

        public Form1()
        {
            InitializeComponent();

            PictureBox[] rigaA = { A1, A2, A3, A4, A5, A6, A7, A8};     //array della riga A
            PictureBox[] rigaB = { B1, B2, B3, B4, B5, B6, B7, B8 };    //array della riga B
            PictureBox[] rigaC = { C1, C2, C3, C4, C5, C6, C7, C8 };    //array della riga C
            PictureBox[] rigaD = { D1, D2, D3, D4, D5, D6, D7, D8 };    //array della riga D
            PictureBox[] rigaE = { E1, E2, E3, E4, E5, E6, E7, E8 };    //array della riga E
            PictureBox[] rigaF = { F1, F2, F3, F4, F5, F6, F7, F8 };    //array della riga F
            PictureBox[] rigaG = { G1, G2, G3, G4, G5, G6, G7, G8 };    //array della riga G
            PictureBox[] rigaH = { H1, H2, H3, H4, H5, H6, H7, H8 };    //array della riga H

            //mette l'immagine della pedina bianca nella riga A
            foreach (PictureBox pb in rigaA) {
                pb.Image = Image.FromFile(pedinaBianca);
                pb.SizeMode = PictureBoxSizeMode.Zoom;
            }

            //mette l'immagine della pedina bianca nella riga B
            foreach (PictureBox pb in rigaB)
            {
                pb.Image = Image.FromFile(pedinaBianca);
                pb.SizeMode = PictureBoxSizeMode.Zoom;
            }

            //mette l'immagine della pedina nera nella riga G
            foreach (PictureBox pb in rigaG)
            {
                pb.Image = Image.FromFile(pedinaNera);
                pb.SizeMode = PictureBoxSizeMode.Zoom;
            }

            //mette l'immagine della pedina nera nella riga H
            foreach (PictureBox pb in rigaH)
            {
                pb.Image = Image.FromFile(pedinaNera);
                pb.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void pictureBox19_Click(object sender, EventArgs e) { }
        private void pictureBox22_Click(object sender, EventArgs e) { }
    }
}
